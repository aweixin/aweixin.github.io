/**
 * 公共参数 例如 openid  , memebrId , userid
 */
export const Server_common = {
	text_id: '123456'
}

export const Method = [
	"POST", "GET", "OPTIONS", "HEAD", "PUT", "DELETE", "TRACE", "CONNECT"
]

export interface optionsType {
	method: "POST" | "GET" | "OPTIONS" | "HEAD" | "PUT" | "DELETE" | "TRACE" | "CONNECT"
	data: any
	header?: Object
}

// 接口数据返回字段
export interface returnType {
	code: number
	data: any
	msg: string
	message: string
}
