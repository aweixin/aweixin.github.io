// 上传图片接口地址
export const uploadFile_url = ''
// 上传携带参数
export const formData = {
	// openid: wx.getStorageSync("openid"),
}
// 后端接收参数 值
export const keyName = 'img';