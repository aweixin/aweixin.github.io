class storage {
	/**
	 * 获取缓存
	 * @param String $key  key
	 * @param any $def  若想要无缓存时，返回默认值则get('key','默认值')（支持字符串、json、数组、boolean等等）
	 * @return value;
	 */
	get(key: string, def: any = '') {
		const timeout = parseInt(wx.getStorageSync(`${key}__separator__`) || '0');
		// 过期失效
		if (timeout) {
			if (Date.now() > timeout) {
				this.remove(key);
				return;
			}
		}
		let value = wx.getStorageSync(key);
		return value ? value : def;
	}

	/**
	 * 设置缓存
	 * @param String $key       key
	 * @param any $value     value（支持字符串、json、数组、boolean等等）
	 * @param Number $timeout   过期时间（单位：分钟）不设置时间即为永久保存
	 * @return value;
	 */
	put(key: string, value: any, timeout: number = 0) {
		let _timeout = Number(timeout + '');
		wx.setStorageSync(key, value);
		console.log(_timeout);
		
		if (_timeout) {
			wx.setStorageSync(`${key}__separator__`, Date.now() + 1000 * 60 * _timeout);
		} else {
			wx.removeStorageSync(`${key}__separator__`);
		}
		return value;
	}

	remove(key: string) {
		wx.removeStorageSync(key);
		wx.removeStorageSync(`${key}__separator__`);
		return undefined;
	}
}

export default new storage();
