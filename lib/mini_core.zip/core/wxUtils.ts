class wxUtils {
	/**
	 * 跳转小程序内部页面 or 网址
	 * @param path （https 跳转网页）
	 */
	public goUrl(path: string) {
		let url = '';
		if (path.includes("https")) {
			url = `/pages/webview/index?url=${encodeURIComponent(path)}`;
		} else {
			url = path;
		}
		wx.navigateTo({
			url: url,
		}).catch((error: any) => {
			console.log(error)
		})
	}

	/**
	* 微信小程序rich-text富文本图片自适应处理
	* @param data html内容
	*/
	public get_html(data: any) {
		var result = data
		result = result.replace(/section/gi, "div")
		result = result.replace(/data-src/gi, "src")
		result = result.replace(/src="data:/gi, 'data-src="data:')
		result = result.replace(/<img[^>]*>/gi, function (match: any) {
			var match = match.replace(/style/gi, "styles")
			return match
		})
		result = result.replace(/\<img/gi, '<img style="max-width:100%!important;height:auto!important;display:block;" ')
		return result
	}
	/**
	* 获取当前点击元素的参数
	* @param e
	*/
	public tapinfo(e: any) {
		return e.currentTarget.dataset
	}

	/**
	* 获取元素信息 DOM
	* @param obj class | ID
	*/
	public getRect(obj: string) {
		return new Promise((resolve, reject) => {
			wx.createSelectorQuery()
				.select(obj)
				.boundingClientRect((rect) => {
					if (rect) {
						resolve(rect)
					} else {
						reject("error")
					}
				})
				.exec()
		})
	}

	// 胶囊按钮与顶部的距离
	public checkFullSucreen() {
		const res = wx.getSystemInfoSync()
		wx.setStorage({
			data: res,
			key: "systemInfo",
		})

		if (wx.getMenuButtonBoundingClientRect()) {
			let menuButtonObject = wx.getMenuButtonBoundingClientRect()
			wx.getSystemInfo({
				success: (res) => {
					let statusBarHeight = res.statusBarHeight,
						navTop = menuButtonObject.top, //胶囊按钮与顶部的距离
						navHeight = statusBarHeight + menuButtonObject.height + (menuButtonObject.top - statusBarHeight) * 2 //导航高度
					wx.setStorage({
						data: navHeight,
						key: "navHeight",
					})
					wx.setStorage({
						data: navTop,
						key: "navTop",
					})
					wx.setStorage({
						data: menuButtonObject,
						key: "menuButtonObject",
					})
				},
			})
		}
	}

	/**
	* 弹窗提示
	* @param content 弹窗内容
	*/
	public alert(content: string) {
		return wx.showModal({
			title: "提示",
			content: content,
			showCancel: false,
		})
	}
	/**
	* 消息提示
	* @param msg 提示内容
	* @param icon success | error
	 * @param duration 例如 1000 一秒
	*/
	public msg(msg: string, icon?: "success" | "error", duration?: number) {
		return new Promise<boolean>((_resolve) => {
			if (msg.length > 7) {
				icon = undefined
			}

			wx.showToast({
				title: msg,
				icon: icon ? icon : "none",
				mask: icon ? true : false,
				duration: duration ? duration : 1500,
				success: () => {
					setTimeout(() => {
						_resolve(true)
					}, 1500)
				},
			})
		})
	}


	/**
	 * 弹窗提示
	 * @param msg 
	 * @param opction 
	 */
	public confirm(msg: string, opction?: {
		showCancel?: boolean
		cancelText?: string
		cancelColor?: string
		confirmText?: string
		confirmColor?: string
	}) {
		return wx.showModal(
			Object.assign(
				{
					title: "提示",
					content: msg,
					showCancel: true,
				},
				opction
			)
		)
	}

	/**
	* 需要预览的图片
	* @param current 当前预览的图片
	* @param urls 所有图片 不存在就是 当前预览图片
	*/
	public previewImage(current: string, urls?: string[]) {
		wx.previewImage({
			current: current, // 当前显示图片的 http 链接
			urls: urls ? urls : [current], // 需要预览的图片 http 链接列表
		})
	}

	/**
	* 订阅消息
	* @param {*} tmplIds 模板ids
	*/
	public requestSubscribeMessage(tmplIds: string[]) {
		return new Promise<any>((resolve) => {
			console.log(`模板---------ids:${tmplIds}`)
			wx.requestSubscribeMessage({
				tmplIds: tmplIds,
				complete(res) {
					resolve(res)
				},
			})
		})
	}

	/**
	* 打开文档
	* @param url
	*/
	public openDocument(url: string) {
		wx.downloadFile({
			url: url,
			success: function (res) {
				const filePath = res.tempFilePath
				wx.openDocument({
					filePath: filePath,
					success: function (res) {
						console.log("打开文档成功")
					},
				})
			},
		})
	}

	/**
	* 检测当前的小程序
	* 版本自动更新
	*/
	public checkUpdateVersion() {
		console.log("checkUpdateVersion")
		//判断微信版本是否 兼容小程序更新机制API的使用
		if (wx.canIUse("getUpdateManager")) {
			//创建 UpdateManager 实例
			const updateManager = wx.getUpdateManager()
			//检测版本更新
			updateManager.onCheckForUpdate(function (res) {
				// 请求完新版本信息的回调
				if (res.hasUpdate) {
					//监听小程序有版本更新事件
					updateManager.onUpdateReady(function () {
						//TODO 新的版本已经下载好，调用 applyUpdate 应用新版本并重启 （ 此处进行了自动更新操作）
						updateManager.applyUpdate()
					})
					updateManager.onUpdateFailed(function () {
						// 新版本下载失败
						wx.showModal({
							title: "已经有新版本喽~",
							content: "请您删除当前小程序，重新搜索打开哦~",
						})
					})
				}
			})
		} else {
			//TODO 此时微信版本太低（一般而言版本都是支持的）
			wx.showModal({
				title: "溫馨提示",
				content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
			})
		}
	}
	/**
	*对象转URL
	*/
	public urlEncode(data: any = {}) {
		var _result = []
		for (var key in data) {
			var value = data[key]
			if (value.constructor == Array) {
				value.forEach(function (_value) {
					_result.push(key + "=" + _value)
				})
			} else {
				_result.push(key + "=" + value)
			}
		}
		return _result.join("&")
	}

	/**
	* 复制内容
	* @param {*} data 复制数据
	* @param {*} title  提示内容
	*/
	public setClipboardData(data: string, title?: string) {
		const self = this;
		wx.setClipboardData({
			data: data,
			success() {
				self.msg(title || "复制成功", "success")
			},
		})
	}

	/**
	* URL 解码
	* @param {string} url encodeURIComponent 编码后的URL
	* @return {*}  返回解码后的URL
	*/
	public decodeURI(url: string) {
		return decodeURIComponent(url)
	}
}

export default new wxUtils();


