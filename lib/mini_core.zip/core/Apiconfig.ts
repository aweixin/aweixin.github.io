const host = ``;
export default {
	'init': `${host}/init`,
}